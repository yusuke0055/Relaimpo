alltype <- function(){c("lmg","pmvd","last", "first", "betasq", "pratt", "genizi", "car")}

